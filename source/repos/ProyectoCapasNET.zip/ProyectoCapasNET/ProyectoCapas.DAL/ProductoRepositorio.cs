﻿using ProyectoCapas.DAL.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoCapas.DAL
{
    public class ProductoRepositorio : IProductoRepository
    {
        private readonly AppDbContext _context;

        public ProductoRepositorio(AppDbContext context)
        {
            _context = context;
        }
        public List<Producto> obtenerTodos()
        {
            return _context.Usuario.ToList();
        }
        public Producto ObtenerPorId(int id)
        {
            return _context.Usuario.FirstOrDefault(p => p.Id == id);
        }
        public void Actualizar(Producto producto)
        {
            var existente = ObtenerPorId(producto.Id);
            if (existente != null)
            {
                _context.Usuario.Update(existente);
                _context.SaveChanges();
            }
        }

        public void Agregar(Producto producto)
        {
            _context.Usuario.Add(producto);
            _context.SaveChanges();
        }

        public void Eliminar(int id)
        {
            var producto = ObtenerPorId(id);
            if (producto != null) {
                _context.Usuario.Remove(producto);
                _context.SaveChanges();
            }
        }

    }
}
